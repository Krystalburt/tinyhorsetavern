<?php
      $servername = "localhost";
      $username = "kburtblu_Zephani";
      $password = "%1;p4{?7~G-i";
      $dbname ="kburtblu_tinyhorsetavern";
      
      // Create connection
      $conn = mysqli_connect($servername, $username, $password, $dbname);
      // Check connection
      if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
      }
      ?>