<h4 class="text-center">Get in touch with us</h4>
<form class="contact-form d-block mx-auto" action="index.php" method="post">
	<center><input class="my-1" type="text" name="name" value="" placeholder="Full Name">
	<input class="my-1" type="text" name="mail" value="" placeholder="Your email">
	<input  class="my-1" type="text" name="subject" value="" placeholder="Subject">
	<textarea class="my-1" name="message" placeholder="Message"></textarea> <br/>
	<button type="submit" name="submit">Submit</button></center>

</form>

<?php

if(isset($POST['submit'])){
	$name = $_POST['name'];
	$subject = $_POST['subject'];
	$from = $_POST['mail'];
	$message = $_POST['message'];

	$mailto ="kburt@kburtdesigns.com";
	$headers = "From: ".$from;
	$txt = "You have a received an email from ".$name."\n\n".$message;

	mail($mailto, $subject, $txt, $headers);
	header("Location: index.php?mailsend");
	
}

	?>