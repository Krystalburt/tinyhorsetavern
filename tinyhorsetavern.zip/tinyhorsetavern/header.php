<header>
<div class="jumbotron jumbotron-fluid">
	<div class="container">
  		<div class="row">
  			<div class="col">
  				<img src="images/logo.png" alt="Tiny Horse Tavern logo" class="logo img-thumbnail mx-auto my-auto d-block">
  			</div>
  		</div>
  	</div>
</div>
</header>
<div id="navbar">
	<nav class="nav navbar navbar-light nav-justified">
		<a class="nav-item nav-link" href="http://kburtdesigns.com/tinyhorsetavern">Home</a>
		<a class="nav-item nav-link" href="#about">About</a>
		<a class="nav-item nav-link" href="#menu">Menu</a>
		<a class="nav-item nav-link" href="#contact">Contact</a>

	</nav>
</div>