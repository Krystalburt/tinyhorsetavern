<!DOCTYPE html>

<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport"><!--favicon-->
  <link href='images/icon.png' rel='icon'><!-- Google Fonts CSS -->
  <link href="https://fonts.googleapis.com/css?family=Almendra|Open+Sans&display=swap" rel="stylesheet"><!-- Bootstrap CSS -->
  <link crossorigin="anonymous" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" rel="stylesheet">
  <link href="styles.css" rel="stylesheet" type="text/css">

  <title>Tiny Horse Tavern</title>
</head>

<body>
  <?php include 'header.php';?>

  <section class="my-5" id="about">
    <div class="container-fluid mx-2">
      <h2 class="text-center">About</h2>


      <div class="row">
        <div class="col-md-6 col-lg-7 col=xl-8"><img alt="Photo of a set rustic dinner table" class="aboutImage mx-auto d-block" src="images/about.png">
        </div>


        <div class="col-md-6 col-lg-5 col=xl-4">
          <div class="my-auto">
          <p>Tiny Horse Tavern was recently purchased by Zephanine, a cute little horse with a birth defect that causes a bone to appear on his forehead. After giving the original owner the only gem he overpaid and in return, the owner turned the tavern over to Zephaniane.</p>


          <p>At Tiny Horse Tavern, we pride ourselves being a non-judgemental place where all can come to eat and rest without the fear of judging. We gladly serve everyone from elves and dwarves to chickens and horses.</p>


          <p>We have some of the cleanest rooms and stables in the area and in addition to taking care of you, we will make sure to take good care of the horses, goats, and any other pack animal that you bring with you to our tavern.</p>


          <p><em>We do collect money for horse birth defect research so that someday we can find a cure for Zephanine. Please see the barkeep if you want to donate.</em>
          </p></div>
        </div>
      </div>
    </div>
  </section>


  <section class="my-5" id="menu">
    <div class="container-fluid my-2">
      <h2 class="text-center">Menu</h2>
      <?php include 'connection.php'?>

      <div class="row p-4">
        <div class=" col-xl-1 col-lg-2 col-sm-12 col-xs-12 justify-content-center">
          <div id="myBtnContainer">
              <center><button class="btn active my-1" onclick="filterSelection('all')">Show all</button> 
              <button class="btn my-1" onclick="filterSelection('breakfast')">Breakfast</button>
               <button class="btn my-1" onclick="filterSelection('lunch')">Lunch</button> 
               <button class="btn my-1" onclick="filterSelection('dinner')">Dinner</button> 
               <button class="btn my-1" onclick="filterSelection('dessert')">Dessert</button> 
               <button class="btn my-1" onclick="filterSelection('drinks')">Drinks</button></center>
          </div>
        </div>


        <div class=" col-xl-11 col-lg-10 col-sm-12 col-xs-12">
          <div class="filterDiv breakfast justify-content-center">
            <div class="row">
              <div class="col-md"><img alt="Image of pancakes topped with rasberries and powdered sugar on white plate" class="categoryImage mx-auto d-block" src="images/breakfast.jpg">
              </div>


              <div class="col-md">
              <h3 class="text-center">Breakfast</h3>
              <?php $sql = "SELECT CATEGORY, FOOD, TAGLINE, DESCRIPTION, PRICE FROM menu WHERE CATEGORY = 'breakfast'";
                                $result = $conn->query($sql);
                                include 'query.php'?>
              <img alt="floraly divider" class="hr mx-auto d-block" src="images/hr.png">
              </div>
            </div>
          </div>


          <div class="filterDiv lunch">
            <div class="row">
              <div class="col-md"><img alt="Image of bread with condiments" class="categoryImage mx-auto d-block" src="images/lunch.jpg">
              </div>


              <div class="col-md">
              <h3 class="text-center">Lunch</h3>


              <h4 class="text-center">Soup</h4>
              <?php $sql = "SELECT CATEGORY, FOOD, TAGLINE, DESCRIPTION, PRICE FROM menu WHERE CATEGORY = 'soup'";
                               $result = $conn->query($sql);
                               include 'query.php'?>

              <h4 class="text-center">Salad</h4>
              <?php $sql = "SELECT CATEGORY, FOOD, TAGLINE, DESCRIPTION, PRICE FROM menu WHERE CATEGORY = 'salad'";
                               $result = $conn->query($sql);
                               include 'query.php'?>

                <img alt="floraly divider" class="hr mx-auto d-block" src="images/hr.png">
              </div>
            </div>
          </div>


          <div class="filterDiv dinner">
            <div class="row">
              <div class="col-md"><img alt="Image of turkey dinner" class="categoryImage mx-auto d-block" src="images/dinner.jpg">
              </div>


              <div class="col-md">
              <h3 class="text-center">Dinner</h3>
              <?php $sql = "SELECT CATEGORY, FOOD, TAGLINE, DESCRIPTION, PRICE FROM menu WHERE CATEGORY = 'dinner'";
                              $result = $conn->query($sql);
                              include 'query.php'?>
              <img alt="floraly divider" class="hr mx-auto d-block" src="images/hr.png">
              </div>
            </div>
          </div>


          <div class="filterDiv dessert">
            <div class="row">
              <div class="col-md">
                <img alt="Image of plumb cake" class="categoryImage mx-auto d-block" src="images/dessert.jpg">
              </div>


              <div class="col-md">
              <h3 class="text-center">Dessert</h3>
              <?php $sql = "SELECT CATEGORY, FOOD, TAGLINE, DESCRIPTION, PRICE FROM menu WHERE CATEGORY = 'dessert'";
                               $result = $conn->query($sql);
                               include 'query.php'?>

              <img alt="floraly divider" class="hr mx-auto d-block" src="images/hr.png">
              </div>
            </div>
          </div>


          <div class="filterDiv drinks">
            <div class="row">
              <div class="col-md"><img alt="Close up of wooden beer keg" class="categoryImage mx-auto d-block" src="images/drink.jpg">
              </div>


              <div class="col-md">
              <h3 class="text-center">Drinks</h3>
              <?php $sql = "SELECT CATEGORY, FOOD, TAGLINE, DESCRIPTION, PRICE FROM menu WHERE CATEGORY = 'drinks'";
                              $result = $conn->query($sql);
                              include 'query.php'?>

              <h4 class="text-center">Alcohol</h4>
              <?php $sql = "SELECT CATEGORY, FOOD, TAGLINE, DESCRIPTION, PRICE FROM menu WHERE CATEGORY = 'alcohol'";
                              $result = $conn->query($sql);
                              include 'query.php'?>
                <img alt="floraly divider" class="hr mx-auto d-block" src="images/hr.png">
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php mysqli_close($conn);?>
    </div>
  </section>


  <section id="contact">
    <div class="container-fluid mx-2">
      <h2 class="text-center">Contact us</h2>


      <div class="row">
        <div class="col-md-6 col-lg-6 col-xl-6">
          <img alt="Tiny Horse Tavern Logo" class="contactImage mx-auto d-block" src="images/logo.png">

          <div class="row">
            <div class="col-md-6 col-lg-6 col-xl-6">
              <h4 class="text-center"><strong>Address:</strong>
              </h4>


              <p class="text-center">123 N Merriweather Lane</p>
            </div>


            <div class="col-md-6 col-lg-6 col-xl-6">
              <h4 class="text-center"><strong>Phone:</strong>
              </h4>


              <p class="text-center">169-578-5792</p>
            </div>
          </div>
        </div>


        <div class="col-md-6 col-lg-6 col-xl-6">
          <?php include 'form.php';?>
        </div>
      </div>
    </div>
  </section>



  </body>


  <footer>
    <?php include 'footer.php';?>
  </footer>
  <script crossorigin="anonymous" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" src="https://code.jquery.com/jquery-3.3.1.slim.min.js">
  </script> 
  <script crossorigin="anonymous" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js">
  </script> 
  <script crossorigin="anonymous" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js">
  </script>
  <script src="nav.js"></script>
  <script src="filter.js"></script>
</html>