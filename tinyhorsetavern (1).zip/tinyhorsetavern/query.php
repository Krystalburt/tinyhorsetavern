<?php
if ($result->num_rows > 0) {
      // output data of each row
      while($row = $result->fetch_assoc()) {
        echo 
        "<div class=\"row\">
            <div class=\" col\">
              <h3 class=\"text-left\">" . $row["FOOD"]. "</h3>
            </div>
            <div class=\"col\">
              <p class=\"text-right\">$".$row["PRICE"]."
            </div>
        </div>
        <div class=\"row\">
            <div class=\"col\">
              <p class=\"text-center\"><strong> " . $row["TAGLINE"]. "</strong><br>"
                . $row["DESCRIPTION"]."</p>
              </div>
            </div>";
    }
    } else {
      echo "0 results";
    }
    ?>