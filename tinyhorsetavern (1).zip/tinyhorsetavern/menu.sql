-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 19, 2019 at 06:28 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `menu`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CATEGORY` varchar(255) COLLATE utf8_bin NOT NULL,
  `FOOD` varchar(255) COLLATE utf8_bin NOT NULL,
  `TAGLINE` varchar(255) COLLATE utf8_bin NOT NULL,
  `DESCRIPTION` varchar(500) COLLATE utf8_bin NOT NULL,
  `PRICE` decimal(6,2) NOT NULL,
  UNIQUE KEY `ID` (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`ID`, `CATEGORY`, `FOOD`, `TAGLINE`, `DESCRIPTION`, `PRICE`) VALUES
(1, 'breakfast', 'Treasure Hunters Breakfast Combo', 'Every adventurer needs to start the day right!', 'Includes: <em>orange juice, biscuits and gravy, and fresh seasonal fruit.</em>', '12.00'),
(2, 'dinner', 'Dwarf Combo', 'This combo dwarfs you!', 'Includes: <em>pint of craft beer, garlic-battered fish, seasoned ships and seasonal cobbler</em>', '15.00'),
(3, 'dessert', 'Seasonal Cobbler', 'Homemade cobbler that clobbers in flavor!', 'Includes: <em>cobbler made with seasonal fruit served a la mode with your choice of chocolate or caramel sauce </em>', '3.75'),
(4, 'dinner', 'Wood Elf Combo', 'Meat Free is the way to be!', 'Includes: <em> glass of wine, deep fried zucchini, house artichoke dip, and seasonal cobbler</em>', '17.00'),
(5, 'breakfast', 'Halfling Full Breakfast', 'For when your really hungry!', 'Includes: <em>mini quiche with cheese, bacon or vegetables, Honey-nut Cake and marmalade, Halfling Hash, ham omlet with curry spices onions and tomatoes, biscuits topped with sausage eggs and gravy</em>', '25.00'),
(6, 'breakfast', 'The Leeroy Jenkins Breakfast', 'For those without fear!', 'Includes: <em>dark roast coffee, two eggs cooked to order, 2 links spicy Cajun sausage, 2 slices applewood smoked bacon, and 1 waffle with jalapeno-orange marmalade</em>', '20.00'),
(7, 'alcohol', 'High Elf Wine', 'From the only creatures that have the time to do wine right!', 'A full-bodied fruity soft wine made by handmade and sealed for 1000 years till the fermentation is at its peak ', '15.00'),
(8, 'drinks', 'Coffee', 'Just your average coffee!', 'Fresh ground coffee served with milk', '2.00'),
(9, 'dessert', 'Seasonal Pie', 'Hoofmade piping hot pie!', 'Includes:<em> pie made with seasonal fruit, served a la mode with your choice of chocolate or caramel sauce</em>', '3.75'),
(10, 'salad', 'Hey is for Horses Salad', 'Your horses will love it, but so will you!', 'Includes: <em>hearty salad with romaine lettuce, nastersum blossoms, artichoke hearts, carrots, cucumber, zucchini, walnuts, and apple slices. Served with pumpkin vinaigrette.</em> <br/><span style=\"font-size: 15px\";\"><strong>Add side of of alfalfa or hay for $2. </strong></span>', '15.00'),
(11, 'breakfast', 'Scone', 'Quick breakfast when your on the go!', 'Includes:<em>freshly baked with scone with seasonal fruit, marmalade, and butter</em>', '9.00'),
(12, 'soup', 'Beef Stew', 'Tender beef is simmered in a super flavorful and hearty broth that is packed with veggies!', 'Includes:<em> A hearty bowl of soup and a side of freshly made bread</em>', '7.50'),
(13, 'alcohol', 'Dwarvian Dinner Beer', 'Made by true craft men!', 'Beer hand crafted with the best barley from the Dalbuldihr Mine workers.', '5.00'),
(14, 'drinks', 'Tea', 'Simmer down when your wound up!', 'Hot herbal tea served with milk and sugar.', '2.00'),
(15, 'dinner', 'Ork Combo', 'Forget Rabbit Food! Eat the Rabbit!', 'Includes: <em>a pint of craft beer, a cooked rabbit, medium rare steak, pot roast, and mashed potatoes smothered with gravy</em>', '25.00'),
(16, 'dinner', 'Testosterone Kebobs', 'For those who fear carbs!', 'Includes:<em>marinaded beef kebobs with tomato, onion, apple, and more beef</em><br/><strong><span style=\"font-size: 15px\";\">Low-carb and Paleo Friendly</span></strong>', '15.00'),
(17, 'soup', 'Minestrone Soup', 'Warm up with this vegetarian minestrone soup!', 'Includes: A hearty bowl of soup and a side of freshly made bread.', '7.50'),
(18, 'salad', 'Grilled Vegan Caesar Wedges', 'This salad is hot!', 'Includes: <em>lightly charred romaine, drizzled with an irresistibly tangy cashew vegan Caesar dressing.<br/><strong>Add chicken for $5</strong>', '9.00'),
(19, 'dessert', 'Plumb Cake', 'Your mouth will be celebrating this festive cake!', 'Includes: <em>Includes a warm piece of cake topped with vanilla ice cream</em>', '3.75'),
(20, 'drinks', 'Juice', 'Morning started right!', 'Freshly squeezed Orange or Apple Juice', '2.00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
